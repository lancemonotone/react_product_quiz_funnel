// import {describe, it, expect, beforeEach} from 'vitest';
// import {render, fireEvent} from '@testing-library/react';
// import {ChoiceProps} from '../types';
// import {SelectedChoicesContext} from '../contexts/SelectedChoicesContext';
// import {QuizProvider} from '../contexts/QuizContext';
// import Question from '../components/Question';
